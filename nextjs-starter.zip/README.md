# Octavia Next.js Starter

Project starter generated successfully.